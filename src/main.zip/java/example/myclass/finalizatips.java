package example.myclass;

public class finalizatips {
    public String Username;
    public String tips;
}
