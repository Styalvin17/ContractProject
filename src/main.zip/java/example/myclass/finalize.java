package example.myclass;

public class finalize {
}
