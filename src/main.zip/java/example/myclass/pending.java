package example.myclass;
public class pending{
    public String Contractname;
    public String begintime;
    public String toedit;
}